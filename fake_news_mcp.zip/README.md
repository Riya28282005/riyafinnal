Fake News Classifier + MCP package
---------------------------------
Files:
- api.py           : FastAPI backend exposing /predict (deploy this to Render)
- mcp_server.py    : MCP server that calls your Render API (run locally or on a server)
- requirements.txt : Python deps for the API (and MCP server)

Quick deploy steps:
1) Deploy API to Render (or any host):
   - Push files to GitHub and create a Web Service on Render.
   - Build command: pip install -r requirements.txt
   - Start command: uvicorn api:app --host 0.0.0.0 --port $PORT
   - After deploy, note the public URL (e.g. https://your-app.onrender.com)
   - Update API_URL in mcp_server.py with that URL (must include /predict)

2) Run MCP server (locally):
   - Create a virtualenv and install mcp and requests: pip install -r requirements.txt
   - Run: python mcp_server.py
   - Then connect your MCP client (e.g., Claude Desktop) to the MCP server address (usually http://localhost:PORT)

Notes:
- The model 'facebook/bart-large-mnli' is large; first-time loading may take time or require more memory.
- If Render free-tier times out, consider lazy-loading or using a bigger instance.
