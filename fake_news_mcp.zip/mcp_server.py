from mcp.server import Server
import requests

server = Server("fake-news-ai")

# Replace with your deployed Render API URL (note: /predict endpoint)
API_URL = "https://YOUR-RENDER-APP.onrender.com/predict"  # <-- apna Render API URL daalna

@server.tool()
def fake_news_checker(text: str) -> str:
    """Send text to the API and get prediction"""
    try:
        resp = requests.post(API_URL, json={"text": text}, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            return f"Prediction: {data.get('label')}, Confidence: {data.get('confidence')}%"
        else:
            return f"API Error: {resp.status_code} - {resp.text}"
    except Exception as e:
        return f"Connection Error: {str(e)}"

if __name__ == "__main__":
    server.run()
