from fastapi import FastAPI
from pydantic import BaseModel
from transformers import pipeline

# Initialize FastAPI app
app = FastAPI(title="Fake News Classifier API")

# Load AI model once at startup
classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")

# Request body model
class InputData(BaseModel):
    text: str

@app.post("/predict")
def predict(data: InputData):
    labels = ["real news", "fake news"]
    result = classifier(data.text, candidate_labels=labels)
    predicted_label = result["labels"][0]
    predicted_score = float(result["scores"][0]) * 100
    return {
        "label": predicted_label,
        "confidence": round(predicted_score, 2)
    }

@app.get("/")
def home():
    return {"message": "Fake News Classifier API is running"}
